
%importedData = readmatrix("sys_data.csv");
%importedData = readmatrix("sys_data_3_crop_end.csv");
%importedData = readmatrix("sys_data_3_straight_end.csv");
importedData = readmatrix("prechod.csv");
importedData2 = readmatrix("sys_data_3.csv");

%importedData = readmatrix("sys_data_straight_end.csv");

sysdata = importedData;
sysdata2 = importedData2;
HeatingOut = sysdata(:, 3);  
HeatingOut2 = sysdata2(:, 3);  

%offset 
WaterTemp_off = sysdata(:, 4)-20.0991020202637;  
WaterTemp = sysdata(:, 4); 
WaterTempOrig = sysdata2(:,4);

x_values2 = 1:length(WaterTempOrig);
x_values2 = x_values2(2:end);
x_values2 = [0,x_values2];
% zajisteni f(0)=0
x_values = 1:length(HeatingOut);
x_values = x_values(2:end);
x_values = [0,x_values];

figure(1)
plot(x_values, HeatingOut);  
hold on; 
plot(x_values, WaterTemp); 
hold on; 
plot(x_values, WaterTemp_off); 
hold off; 
title('vstupně/výstupní data');
xlabel('Index');
ylabel('Y-axis Values');
legend('HeatingOut', 'WaterTemp','WaterTempOffset');  

figure(2)
plot(x_values2, HeatingOut2);  
hold on;
plot(x_values2, WaterTempOrig); 
hold off; 
title('vstupně/výstupní data');
xlabel('Time in 10ms');
ylabel('Y-axis Values');
legend('HeatingOut','WaterTempOriginal');  

pidTuner(tf4)

